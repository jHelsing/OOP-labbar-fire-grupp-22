/*Tobias Alld�n och Jonathan Helsing
 * Grupp 22
 * 
 * */

public class HelloWorld {
/*A program to display the message
"Hello World!" on standard output
*/
	public satic void main(String[] args)	{
		System.out.println("Hello World!");
	}
}//	end	of class HelloWorld
